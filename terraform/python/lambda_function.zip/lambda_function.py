import json
import boto3

def sum(number1,number2):
    res = number1+number2
    return str(res)

def lambda_handler(event, context):

    if not 'number1' in event or not 'number2' in event :
        return {
            'statusCode': 200,
            'body': json.dumps('Error: Please specify all parameters (number1 and number2).')
        }
    res=sum(event['number1'],event['number2'])
    client = boto3.client('sns')
    snsArn = 'arn:aws:sns:eu-central-1:815197024081:sns_topic'
    message = "sum = " +str(res)
    response =client.publish(TopicArn = snsArn,Message = message ,Subject='sum of numbers')
    
    return {
        'statusCode': 200,
        'body': json.dumps ( 'the sum is  '+ res )
    }